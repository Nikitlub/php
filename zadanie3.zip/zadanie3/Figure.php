<?
Class Figure{
                  
    function __construct ( $type='', $a, $b = null, $c = null )
        {
            if ( $type == 'square' ){                  
                echo $type . '  Area: ' . ( $a * $a );                              
            } elseif ( $type == 'triangle' ){
                $p = ( $a + $b + $c )/2;
                echo $type . '  Area: ' . ( sqrt ( $p * ( $p - $a ) * ( $p - $b ) * ( $p - $c )));                  
            } elseif ( $type == 'circle' ){
                echo $type . '  Area: ' . ( M_PI * $a * $a );
            } else { 
                echo ''; 
            }                                   
        }              
}
$file = fopen ( "file.txt", "r+" );
    while ( !feof ( $file )) {
        $fig = explode (",", fgets ( $file ));   
        $out = new Figure ( $fig[0], $fig[1], $fig[2], $fig[3] );
        echo '<br>';    
}
?>